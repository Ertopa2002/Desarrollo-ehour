# Placeholder for oracledb module (simulado)
